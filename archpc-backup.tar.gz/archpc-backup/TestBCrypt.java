
import org.mindrot.jbcrypt.BCrypt;

public class TestBCrypt {
  public static void main(String[] args) {
    String hash = "$2b$12$Rpgbwloez26OOLWlR10gPeyrYdzB8FjZVWi3zlY.fIjbez.tRWXdO";
    try {
      boolean ok = BCrypt.checkpw("password", hash);
      System.out.println("OK=" + ok);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
